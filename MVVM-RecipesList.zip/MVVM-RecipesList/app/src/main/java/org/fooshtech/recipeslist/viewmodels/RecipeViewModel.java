package org.fooshtech.recipeslist.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;


public class RecipeViewModel extends AndroidViewModel {


    public RecipeViewModel(@NonNull Application application) {
        super(application);

    }



}